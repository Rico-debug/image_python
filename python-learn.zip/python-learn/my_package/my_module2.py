"""
自定义模块2
"""

def info_print2():
    print("我是模块2的功能函数代码")

