"""
演示自定义模块1
"""

def info_print1():
    print("我是模块1的功能函数代码")

