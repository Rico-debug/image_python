"""
演示while循环的基础应用
"""
i = 0
while i < 100:
    print("小美，我喜欢你")
    i += 1

