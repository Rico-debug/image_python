class Student:
    name = None
    age = None

    def say_hi(self):
        print(f"你好，我是{self.name},我的年纪是{self.age}")
    def say_hi2(self, msg):
        print(f"你好，我是{msg},我的年纪是{self.age}")


stu_1 = Student()
stu_1.name = "Jay"
stu_1.age = 12

stu_1.say_hi()
stu_1.say_hi2("hahaha")