#设计类
class Student:
    name = None
    age = None

#创建对象
stu_1 = Student()

#对象赋值
stu_1.name = "Jay"
stu_1.age = 11

#获取对象信息
print(stu_1.name)
print(stu_1.age)


