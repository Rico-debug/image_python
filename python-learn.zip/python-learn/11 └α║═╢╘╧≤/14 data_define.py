'''
数据定义的类
'''

class Record:

    def __int__(self, data, order, money, province):
        self.data = data
        self.order = order
        self.money = money
        self.province = province


