class Phone:
    __voltage = None

    def __keep_low_battery(self):
        print("单核运行")

    def call_5G(self):
        if self.__voltage >= 1:
            print("可以使用5G")
        else:
            self.__keep_low_battery()
            print("电量不足，无法使用")

phone = Phone()
phone.__voltage
phone.__keep_low_battery
