class Phone:
    IMEI = None
    producer = "None"

    def call_by_4G(self):
        print("4G")

class Phone2022(Phone):
    face_ID = None
    producer =  "xiaomi"

    def call_by_4G(self):
        print("new 4G")

    def call_by_5G(self):
        super().call_by_4G()
        Phone.call_by_4G(self)
        print("5G")

apple = Phone2022()
apple.call_by_5G()