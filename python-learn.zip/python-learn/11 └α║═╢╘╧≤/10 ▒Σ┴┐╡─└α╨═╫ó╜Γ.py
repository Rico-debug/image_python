#变量注解
import json
import random

# var_1: int = 10
# var_2: float = 1.1

#方法注解
class Student:
    pass

stu: Student = Student()

#容器类型注解
#简略
my_list: list = [1, 2, 3]
my_tuple: tuple = (1, 2, 3)
my_set: set = {1, 2, 3}
#详细
my_list1: list[int] = [1, 2, 3]
my_tuple1: tuple[int, float, str] = (1, 2.1, "haha")
my_set1: set[int] = {1, 2, 3}
my_dict: dict[str, int] = {"haha":666}

#通过注释注解
var_1 = random.randint(1, 10)  # type: int
var_2 = json.loads('{"name": "zhangsan"}')  # type: dict[str, str]

def fuc():
    return 10

var_3 = fuc()   #type:int
