class Student:
    def __init__(self, name, age, address):
        self.name = name
        self.age = age
        self.address = address

for i in range(1, 10) :
    stu = Student(input(str("请输入学生姓名：")), input(str("请输入学生年纪：")), input(str("请输入学生地址：")))
    print(f"学生{i}录入完成，信息为：学生姓名：{stu.name}，年纪{stu.age}，地址{stu.address}")
    i +=1
