
class Student:
    name = None
    age = None

    def __init__(self, name, age):
        self.name = name
        self.age = age
        print("创建了一个对象")

stu = Student("zhou", 31)
print(stu.name)
print(stu.age)

