def fuc(data:list):
    data.append()