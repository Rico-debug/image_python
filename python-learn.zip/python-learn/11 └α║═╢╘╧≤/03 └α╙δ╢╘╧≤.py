import winsound

winsound.Beep(8000, 4000)