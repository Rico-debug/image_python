class Student:
    def __init__(self, name, age):
        self.name = name
        self.age = age

    def __str__(self):
        return f"name = {self.name}, age = {self.age}"

    def __lt__(self, other):
        return self.age < other.age

    def __le__(self, other):
        return self.age <= other.age

    def __eq__(self, other):
        return self.age == other.age

stu = Student("jay", 11)
print(stu)
print(str(stu))

stu_1 = Student("jjj", 12)
stu_2 = Student("bbb", 15)
print(stu_1 > stu_2)
print(stu_1 >= stu_2)

stu_3 = Student("qqq", 15)
print(stu_2 == stu_3)

