from typing import  Union
my_list:list[Union[str, int]] = [1, 2, "jay"]
my_dict:dict[str, Union[str, int]] = {"name":"jay", "age":31}

def fuc(data:Union[int, str]) ->Union[int, str]:
    pass


fuc()