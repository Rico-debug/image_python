class Phone:
    IMEI = None
    producer = None

    def call_by_4G(self):
        print("4G")

class Phone2022(Phone):
    face_ID = None

    def call_by_5G(self):
        print("5G")

class Phone11(Phone, Phone2022):
    pass

apple = Phone11()
apple.call_by_4G()